#include <iostream>
#include "header.hpp"

int main(){
	std::cout<<std::endl; 
	std::cout<<"===Program by Savoy Smith==="<<std::endl; 
	std::cout<<"==CSCI2270 Final Project=="<<std::endl; 
	std::cout<<"   Creates a Graph of NBA Players including their stats and other information."<<std::endl; 
	std::cout<<"   Adjacent vertices are populated by a players teamates and then when the "<<std::endl; 
	std::cout<<"   printRoster() method is called, a linked list is created of teamates on a "<<std::endl; 
	std::cout<<"   given team based on each teamates ppg."<<std::endl; 
	std::cout<<"================================================================================"<<std::endl; 
	std::cout<<std::endl; 

	read_data r_d; //Read data class definition
	Graph _Graph; 
	playerNodeFunctions pnf; 

	bool user_chose_to_quit = false; 
	while(!user_chose_to_quit){
		std::cout<<"1. Lookup Player"<<std::endl;
		std::cout<<"2. Browse Teams"<<std::endl; 
		std::cout<<"3. View Statistics Rankings"<<std::endl; 
		std::cout<<"4. Print All NBA Players"<<std::endl; 
		std::cout<<"5. Quit"<<std::endl; 

		std::string choice; 
		getline(std::cin, choice); 

		if(choice == "1"){
			//Lookup player
			std::string name;
			std::cout<<"Enter player's full name"<<std::endl; 
			getline(std::cin, name); 
			pnf.findPlayer(name); 
		} 

		else if(choice == "2"){
			//Browse Teams
			std::cout<<"Choose a team"<<std::endl;
			std::string _choice; 
			pnf.printTeams(); 
			getline(std::cin, _choice); 
			pnf.printRoster(_choice); 
			std::cout<<std::endl;
		}

		else if(choice == "3"){
			//Print Stat ranks
			pnf.printStatCat(); 
			std::cout<<std::endl;
		}

		else if(choice == "4"){
			//Print all players 
			pnf.printAllPlayers();
			std::cout<<std::endl; 
		}


		else if(choice == "5"){
			return 0; 
		}

		else{
			std::cout<<"Incorrect Input! Enter a valid input."<<std::endl; 
		}

	}
	

	return 0; 
}