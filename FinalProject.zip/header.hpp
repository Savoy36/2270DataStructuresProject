#ifndef HEADER_HPP
#define HEADER_HPP
#include <vector>

struct player{//player struct for a linked list 

	int rk;//Player rank based on ppg 
	std::string name;//Player name 
	std::string pos;//Player position 
	int age;//players age	
	std::string tm;//team abreviation 
	int gp; 
	int gs;
	double mp;//minutes played per game 
	double fgm;//field goals made per game 
	double fga;//field goals attempted 
	float fgp;//field goal percentage 
	double tpm;//3 pointers made per game 
	double tpa; 
	float tpp;//3 point percentage
	float twpm;//2 pointers made per game
	float twpa;//2 pointers attempted 
	float twpp;//2 point percentage 
	float efgp;//Efficiency field goal percentage 
	double ftm;//Free throws made per game 
	double fta;//Free throws attempted 
	double ftp;//Free throw percentage 
	double orb;//Offensive rebounds per game 
	double drb;//Deffensive rebounds per game
	double trb;//Total rebounds per game 
	double ast;//Assists per game 
	double stl;//Steals per game  
	double blk;//blocks per game 
	double tov;//turnovers per game 
	double pf;//player foulds per game 
	double ppg;//points per game 
	std::string teamname;//Team name 
	std::string salary;//annual salary 

	player(int _rk, std::string _name, std::string _pos, int _age, std::string _tm, int _gp, int _gs, double _mp, double _fgm, double _fga, float _fgp, double _tpm, double _tpa, float _tpp, double _twpm, double _twpa, float _twpp, float _efgp, double _ftm, double _fta, float _ftp, double _orb, double _drb, double _trb, double _ast, double _stl, double _blk, double _tov, double _pf, double _ppg, std::string _teamname, std::string _salary)
	{

		rk=_rk; 
		name = _name;
		pos=_pos;
		age=_age;
		tm=_tm; 
		gp=_gp;
		gs=_gs;
		mp=_mp;
		fgm=_fgm;
		fga=_fga; 
		fgp=_fgp; 
		tpm=_tpm; 
		tpa=_tpa;
		tpp=_tpp;
		twpm=_twpm;
		twpa=_twpa;
		twpp=_twpp;
		efgp=_efgp; 
		ftm=_ftm;
		fta=_fta; 
		ftp=_ftp; 
		orb=_orb;
		drb=_drb; 
		trb=_trb; 
		ast=_ast; 
		stl=_stl; 
		blk=_blk; 
		tov=_tov; 
		pf=_pf; 
		ppg=_ppg; 
		teamname=_teamname; 
		salary=_salary; 
	}
};

struct vertex; 

struct adjVertex{
	vertex *v;  
};

struct vertex{
	player *playerNode; 
	std::vector<adjVertex> adj; 
};


struct teamate{
	teamate *next; 
	teamate *prev; 
	std::string teamname; 
	player *playerNode; 
	 
	teamate(teamate *_next, teamate *_prev, std::string _teamname, player *_playerNode){
		next = _next; 
		prev = _prev;
		teamname = _teamname; 
		playerNode = _playerNode; 

	}
};


class read_data
{
public:
	read_data();
	~read_data(); 
	void readFileIn();
	void insertPlayerIntoGraph(std::string line_data[]);
	void addVertex(player *playerNode); 
 
protected:
	std::vector<vertex> graph_vertices; 

private:
	int playersPushed; 
};


class Graph: protected read_data
{
public:
	Graph();
	~Graph();
	void findAdjVertices(int vertex_index);//Finds players with the same first letter in their last name to create an alphabetical graph where adj vertices are those that share the same last name initial. 
	bool isVecEmpty(adjVertex _adj); 
	void buildRoster(vertex v);
	void buildRosterRoot(player *playerNode);
	void buildRosterLinkedList(player *playerNode);
	bool isPlayersTeamBuilt(player *playerNode);//Checks if a player is already in a roster or if the players roster vector exitsts 

protected: 
	std::vector<teamate*> roster; //Vector full of roots of linked lists populated by teamates.
	std::vector<vertex> vertices;
private:
	int numOfTeams; //Number of teams in the roster vector. 
}; 


class playerNodeFunctions: protected Graph{
public:
	playerNodeFunctions(); 
	~playerNodeFunctions(); 
	void printPlayerStats(player *playerNode);
	void printTeams();
	void printRoster(std::string choice); 
	void printStatCat(); 
	void printTopTens(std::string choice); 
	void printAllPlayers();  
	void findPlayer(std::string name); 
private:
	bool findInt(int myInt, int *FGP);//Used for sorting ints
};


#endif //HEADER_HPP