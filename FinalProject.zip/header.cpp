#include <iostream>
#include "header.hpp"
#include <fstream> 
#include <vector>
#include <algorithm>
#include <string>

read_data::read_data(){
	playersPushed = 0; 
	readFileIn(); 
}

read_data::~read_data(){}; 

void read_data::readFileIn(){
	std::string filename = "nbasalariespoints.txt"; 
	std::ifstream csvfile; 
	csvfile.open(filename); 
	if(csvfile.is_open()){
		std::string line;//line of data in file
		
		while(getline(csvfile, line)){
			std::string line_data[31]; 
			int itt=0;//counts itteration for line_data array 
			while(itt < 31){
				if(itt != 30){
					line_data[itt] = line.substr(0,line.find(",")); 
					//std::cout<<line_data[itt]<<"   itt: "<<itt<<std::endl; 
					line.erase(0,line.find(",")+1);  
					itt++; 
				}
				else if(itt == 30){
					line.erase(0,1);
					if(line.find("\"") == -1){ 
						line_data[itt] = line.substr(0,line.find(",")); 
						//std::cout<<line_data[itt]<<"   itt: "<<itt<<std::endl; 
						line.erase(0,line.find(",")+1); 
						itt++; 
					}
					else{ 
						line.pop_back();
						line_data[itt] = line;
						line.erase(0,line.find_last_of("\"")); 
						//std::cout<<line_data[itt]<<"   itt: "<<itt<<std::endl; 
						itt++; 
					}
				}
			}
			
			insertPlayerIntoGraph(line_data);  			 
		}
	}
	else{
		std::cout<<"file did not open"<<std::endl;
	}
}


void read_data::insertPlayerIntoGraph(std::string line_data[]){
	playersPushed++; 
	player *playerNode = new player(playersPushed,line_data[0],line_data[1],std::stoi(line_data[2]),line_data[3],std::stoi(line_data[4]),std::stoi(line_data[5]),std::stod(line_data[6]),std::stod(line_data[7]),std::stod(line_data[8]),std::stof(line_data[9]),std::stod(line_data[10]),std::stod(line_data[11]),std::stof(line_data[12]),std::stof(line_data[13]),std::stof(line_data[14]),std::stof(line_data[15]),std::stof(line_data[16]),std::stod(line_data[17]),std::stod(line_data[18]),std::stod(line_data[19]),std::stod(line_data[20]),std::stod(line_data[21]),std::stod(line_data[22]),std::stod(line_data[23]),std::stod(line_data[24]),std::stod(line_data[25]),std::stod(line_data[26]),std::stod(line_data[27]),std::stod(line_data[28]),line_data[29],line_data[30]);
	addVertex(playerNode); 

}

playerNodeFunctions::playerNodeFunctions(){}
playerNodeFunctions::~playerNodeFunctions(){}

void playerNodeFunctions::printPlayerStats(player *playerNode){
	std::cout<<"# # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # #"<<std::endl; 
	std::cout<<playerNode -> name<<"'s 2015 - 2016 game statistics:"<<std::endl; 
	std::cout<<"Team: "<<playerNode -> teamname<<std::endl;
	std::cout<<"Age: "<<playerNode -> age<<std::endl;  
	std::cout<<"Position: "<<playerNode -> pos<<std::endl; 
	std::cout<<"Games played: "<<playerNode -> gp<<std::endl; 
	std::cout<<"======="<<std::endl; 
	std::cout<<"PPG: "<<playerNode -> ppg<<std::endl;	
	std::cout<<"FG: "<<playerNode -> fgm<<std::endl; 
	std::cout<<"FG %: "<<playerNode -> fgp<<std::endl; 
	std::cout<<"3 point %: "<<playerNode -> tpp<<std::endl; 
	std::cout<<"Free throw %: "<<playerNode -> ftp<<std::endl; 
	std::cout<<"Rebounds per game: "<<playerNode -> trb<<std::endl; 
	std::cout<<"Assists per game: "<<playerNode -> ast<<std::endl; 
	std::cout<<"Steals: "<<playerNode -> stl<<std::endl; 
	std::cout<<"Blocks: "<<playerNode -> blk<<std::endl; 
	std::cout<<"Turnovers: "<<playerNode -> tov<<std::endl;   
	if(playerNode -> salary != "$0" || playerNode -> salary != "0"){
		std::cout<<"Annual salary: "<<playerNode -> salary<<std::endl; 
	}
	std::cout<<"# # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # #"<<std::endl; 
	std::cout<<"Hit enter to return to main menu "<<std::endl; 
	std::string lit; 
	getline(std::cin, lit);  
}


Graph::Graph(){
	vertices = graph_vertices;
	numOfTeams = 0; //30 total NBA teams, but 1 more added for those players who are in the NBA, but are Free Agents meaning they are not currently under contract with a team, but player last season. 
	for(int i=0; i<vertices.size(); i++){
		findAdjVertices(i);
	}
	roster[13] -> teamname = "Free Agents"; 
	roster.push_back(roster[13]); 
	roster.erase(roster.begin() + 13); 
}

Graph::~Graph(){

}


void read_data::addVertex(player *player_node){
	//No need to check if player has been found as I optimized the data being read in. 
	vertex v; 
	v.playerNode = player_node; 
	graph_vertices.push_back(v);//Populates a vector of vertices to be organized within the graph function 
 
}

void Graph::findAdjVertices(int vertex_index){
	//If player is a free agent teamname = 0
	for(int i=0; i<vertices.size(); i++){
		if(vertices[vertex_index].playerNode -> teamname == vertices[i].playerNode -> teamname && vertices[vertex_index].playerNode->name != vertices[i].playerNode->name){
			adjVertex av; 
			av.v = &vertices[i]; 
			vertices[vertex_index].adj.push_back(av);//Populates adjacent vertices
		}
	}
	buildRoster(vertices[vertex_index]);  
}


void Graph::buildRosterLinkedList(player *playerNode){
	teamate *walker = roster[numOfTeams]; 
	//std::cout<<"here"<<std::endl; 
	if(walker -> next != nullptr){
		//std::cout<<"in the if loop"<<std::endl; 
		while(walker -> next != nullptr){
			walker = walker -> next; 
		}
		teamate *newTeamate = new teamate(nullptr, walker, playerNode -> teamname, playerNode); 
		//std::cout<<roster[numOfTeams] -> teamname<<std::endl; 
		walker -> next = newTeamate; 

	}
	else{
		//std::cout<<"in the else loop"<<std::endl; 
		teamate *newTeamate = new teamate(nullptr, walker, playerNode -> teamname, playerNode); 
		walker -> next = newTeamate; 
	}
	//std::cout<<"all good"<<std::endl; 

}

void Graph::buildRosterRoot(player *playerNode){
	teamate *newTeamate = new teamate(nullptr, nullptr, playerNode -> teamname, playerNode); 
	roster.push_back(newTeamate); 
	
	//std::cout<<"root all good"<<std::endl; 
}

void Graph::buildRoster(vertex v){ 
	if(!isPlayersTeamBuilt(v.playerNode)){
		buildRosterRoot(v.playerNode);//To start the list 
		for(int i=0; i<v.adj.size(); i++){
			buildRosterLinkedList(v.adj[i].v->playerNode); 
		}
		numOfTeams++;
	}
}


bool Graph::isPlayersTeamBuilt(player *playerNode){
	int t_or_f = 0; 
	for(int i=0; i<roster.size(); i++){
		if(playerNode -> teamname == roster[i] -> teamname){
			//std::cout<<"true"<<std::endl;
			t_or_f = 1; 
			break; 
		}
	}
	if(t_or_f == 1){
		return true; 
	}
	else{
		//std::cout<<"false"<<std::endl;
		return false; 
	}
}


void playerNodeFunctions::printRoster(std::string choice){
	if(choice != "31"){
		int teamIndex = std::stoi(choice) - 1; 
		teamate *walker = roster[teamIndex]; 
		std::cout<<"        The 2015-2016 "<<walker->teamname<<std::endl; 
		std::cout<<"pos - Name     -    ppg"<<std::endl; 
		std::cout<<"______________________________________________________________________"<<std::endl; 
		while(walker -> next != nullptr){
			if(walker -> playerNode -> pos == "C"){
				std::cout<<walker -> playerNode -> pos << "  - "<<walker -> playerNode -> name<< " - "<<walker -> playerNode -> ppg<<std::endl;
			}
			else{
				std::cout<<walker -> playerNode -> pos << " - "<<walker -> playerNode -> name<< " - "<<walker -> playerNode -> ppg<<std::endl;
			}
			walker = walker -> next;  
		}
		std::cout<<walker -> playerNode -> pos << " - "<<walker -> playerNode -> name<< " - "<<walker -> playerNode -> ppg <<std::endl;
		std::cout<<"______________________________________________________________________"<<std::endl;
	}
	else{
		int teamIndex = std::stoi(choice); 
		teamate *walker = roster[teamIndex];
		std::cout<<"       2015 - 2016 Free Agents"<<std::endl; 
		std::cout<<"pos - Name     -    ppg"<<std::endl; 
		std::cout<<"______________________________________________________________________"<<std::endl; 
		while(walker -> next != nullptr){
			if(walker -> playerNode -> pos == "C"){
				std::cout<<walker -> playerNode -> pos << "  - "<<walker -> playerNode -> name<< " - "<<walker -> playerNode -> ppg<<std::endl;
			}
			else{
				std::cout<<walker -> playerNode -> pos << " - "<<walker -> playerNode -> name<< " - "<<walker -> playerNode -> ppg<<std::endl;
			}
			walker = walker -> next; 
		}
		std::cout<<walker -> playerNode -> pos << " - "<<walker -> playerNode -> name<<std::endl;
		std::cout<<"______________________________________________________________________"<<std::endl; 
	}
}

void playerNodeFunctions::printTeams(){
	for(int i=0; i<roster.size(); i++){
		std::cout<<i+1<<". "<<roster[i] -> teamname<<std::endl; 
	}
}

void playerNodeFunctions::printStatCat(){
	std::cout<<"Options will display the top players at each given category"<<std::endl; 
	std::cout<<"1. Points Per Game (ppg)"<<std::endl; 
	std::cout<<"2. Field Goal Percentage (FG%)"<<std::endl; 
	std::cout<<"3. Total Points"<<std::endl; 
	std::cout<<"4. Annual Salary"<<std::endl;

	std::string choice; 
	getline(std::cin, choice); 

	printTopTens(choice); 

}

void playerNodeFunctions::printTopTens(std::string choice){
	if(choice == "1"){
		//PPG Top 10
		std::cout<<"   Name         -    PPG    -    Team"<<std::endl;
		std::cout<<"______________________________________________________________________"<<std::endl;  
		for(int i=1; i<11; i++){
			std::cout<<i<<". "<<vertices[i-1].playerNode -> name<<" - "<<vertices[i-1].playerNode -> ppg<<" - "<<vertices[i-1].playerNode ->teamname<<std::endl;
		}
		std::cout<<"______________________________________________________________________"<<std::endl; 
	}
	else if(choice == "2"){
		//FG% Top 10
		std::vector<float> FGP; 
		for(int i=0; i<vertices.size(); i++){
			FGP.push_back(vertices[i].playerNode -> fgp); 
		}
		for(int i=0; i<FGP.size(); i++){
			if(FGP[i] == 0 || FGP[i] == 1){
				FGP.erase(FGP.begin() + i); 
			}
		}
		std::sort(FGP.begin(), FGP.end()); 
		int rankIndex=1; 
		std::cout<<"   Name         -    FG%    -    Team"<<std::endl;
		std::cout<<"______________________________________________________________________"<<std::endl; 
		for(int i=vertices.size(); i>vertices.size()-10; i--){
			for(int j=0; j<vertices.size(); j++){
				if(FGP[i] == vertices[j].playerNode -> fgp && FGP[i]){
					if(vertices[j].playerNode -> teamname == "0"){
						std::cout<<rankIndex<<". "<<vertices[j].playerNode -> name<<" - "<<vertices[j].playerNode -> fgp<<" - Free Agent"<<std::endl; 
					}
					else{
						std::cout<<rankIndex<<". "<<vertices[j].playerNode -> name<<" - "<<vertices[j].playerNode -> fgp<<" - "<<vertices[j].playerNode ->teamname<<std::endl; 
					}
					rankIndex++; 
					break;
				}
			} 
		}
		std::cout<<"______________________________________________________________________"<<std::endl; 
	}
	else if(choice == "3"){
		//Total Points Top 10
		int totalPoints; 
		std::cout<<"   Name         -    Points    -    Team"<<std::endl;
		std::cout<<"______________________________________________________________________"<<std::endl; 
		for(int i=0; i<10; i++){
			totalPoints = vertices[i].playerNode -> ppg * vertices[i].playerNode -> gp; 
			if(i == 0){
				totalPoints = totalPoints + 25; 
				std::cout<<i+1<<". "<<vertices[i].playerNode -> name<<" - "<<totalPoints<<std::endl; 
			}
			else{
				std::cout<<i+1<<". "<<vertices[i].playerNode -> name<<" - "<<totalPoints<<std::endl; 
			}
		}
		std::cout<<"______________________________________________________________________"<<std::endl; 
	}
	else if(choice == "4"){
		//Salary Top 10
		std::cout<<"   Name         -    Salary "<<std::endl;
		std::cout<<"______________________________________________________________________"<<std::endl; 
		std::vector<int> sal; 
		std::vector<player*> playa; 
		for(int i=0; i<vertices.size(); i++){
			if(vertices[i].playerNode -> salary.find(",") != -1){
				std::string processedStr = vertices[i].playerNode -> salary; 
				processedStr.erase(0,1); 
				while(processedStr.find(",") != -1){
					processedStr.erase(processedStr.begin() + processedStr.find(",")); 
				}
				while(processedStr.find(" ") != -1){
					processedStr.erase(processedStr.begin() + processedStr.find(" "));
				}
				int processedInt = std::stoi(processedStr); 
				sal.push_back(processedInt);
 				playa.push_back(vertices[i].playerNode); 
			}
		}
		std::sort(sal.begin(), sal.end()); 
		int printIndex=1;
		for(int j=0; j<10; j++){
			for(int i=0; i<playa.size(); i++){
				if(playa[i] -> salary.find(",") != -1){
					std::string processedStr = playa[i] -> salary; 
					processedStr.erase(0,1); 
					while(processedStr.find(",") != -1){
						processedStr.erase(processedStr.begin() + processedStr.find(",")); 
					}
					while(processedStr.find(" ") != -1){
						processedStr.erase(processedStr.begin() + processedStr.find(" "));
					}
					if(sal[playa.size()-j] == std::stoi(processedStr)){
						std::cout<<printIndex<<". "<<playa[i] -> name<<" - "<<playa[i] -> salary<<std::endl; 
						printIndex++; 
					}
				}
			}
		}
		std::cout<<"______________________________________________________________________"<<std::endl;
	}

	else{
		std::cout<<"invalid choice"<<std::endl; 
	}
}

void playerNodeFunctions::printAllPlayers(){
	std::cout<<"   Name         -   PPG   -  Team "<<std::endl;
	std::cout<<"______________________________________________________________________"<<std::endl; 
	for(int i=0; i<vertices.size(); i++){
		std::cout<<i+1<<". "<<vertices[i].playerNode -> name<< " - "<<vertices[i].playerNode -> ppg<<" - "<<vertices[i].playerNode -> tm<<std::endl; 
	}
	std::cout<<"______________________________________________________________________"<<std::endl;
}

void playerNodeFunctions::findPlayer(std::string name){
	bool playerFound = false; 
	for(int i=0; i<vertices.size(); i++){
		if(name == vertices[i].playerNode -> name){
			printPlayerStats(vertices[i].playerNode); 
			playerFound = true; 
			break; 
		}
	}
	if(!playerFound){
		std::cout<<"Player not found. Hint: LeBron is spelled with a capital B!"<<std::endl; 
	}
}